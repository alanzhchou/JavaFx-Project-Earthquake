$(function () {
	$('.single-slider').jRange({
		from: 0,
		to: 100,
		step: 1,
		scale: [0, 25, 50, 75, 100],
		format: '%s',
		width: 300,
		showLabels: true,
		showScale: true
	});

	$('.range-slider').jRange({
		from: 0,
		to: 100,
		step: 1,
		scale: [0, 25, 50, 75, 100],
		format: '%s',
		width: 300,
		showLabels: true,
		isRange: true
	});
});